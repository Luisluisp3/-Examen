export const fireBaseconfing = {
  apiKey: "AIzaSyChvA6196lVJx9FY0rnM_VTrZ-K7-9gnxk",
  authDomain: "angular-proyect-7b56f.firebaseapp.com",
  projectId: "angular-proyect-7b56f",
  storageBucket: "angular-proyect-7b56f.firebasestorage.app",
  messagingSenderId: "167821437633",
  appId: "1:167821437633:web:f7d6cb8c8a2072b1f10240",
  measurementId: "G-0HRBH5NMGC"
};
